Assembly instructions
Lucas Koerner
408-386-7832
koerner.lucas@stthomas.edu
2020/11/02

Please populate 2 boards. Almost all parts were order with sufficient quantity for two boards (with overage). 

The exception being the SMA connectors, Bag 45, X1, X2, X3, X4, X5, X6, X7, X8. For this part populate 1 board with all 8 connectors and then on the second board populate X7,X8 only. 

Each set of parts has a number label (in black Sharpie marker) which is indicated as Bag # in the BOM spreadsheet. 

I realize that the Ethernet RJ45 jack is positioned incorrectly (rotated so that the cable will go into the board). This is OK just populate this connector (J3) anyways.

A stencil will be included. 